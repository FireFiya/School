#include "GeometricObject.h"
void GeometricObject::setColor(string color) {
	this->color = color;
}
string GeometricObject::getColor()const {
	return color;
}